# ansible-role-base_setup

OS や基本機能を設定するための ansible role です。


### 注意事項

```base_setup_set_yum_repository=true```に設定した場合、プロジェクト独自で指定するyum repositoryを設定し、デフォルトでenabledになっているyum repositoryをdisableにします。  
copyモジュールを使用してdisableされている*.repoファイルデプロイすることでyum repositoryのdisableを行っています。 
デプロイする*.repoファイルはECLで使用しているファイルのため、環境により異なる場合は*.repoファイルを差し替えてください。  

*.repoファイル格納場所  
```
files/yum.repos.d/
```
