#!/bin/sh

LANG=C

expect -c '
spawn fdisk /dev/vdb
        expect {
                "Command*" {
                        send "n\r"
                        exp_continue
                }
                "Select*" {
                        send "\r"
                        exp_continue
                }
                "Partition*" {
                        send "\r"
                        exp_continue
                }
                "First*" {
                        send "\r"
                        exp_continue
                }
                "Last*" {
                        send "\r"
                }
        }

expect {
        "Command*" {
                send "w\r"
                sleep 10
                exit
        }
}
'
exit 0
