# -*- coding:utf8 -*-

def test_base_setup_pkg_is_installed(host):
    yumutils = host.package("yum-utils")
    wget = host.package("wget")
    unzip = host.package("unzip")
    assert yumutils.is_installed
    assert wget.is_installed
    assert unzip.is_installed

def test_rsyslog_running_and_enabled(host):
    rsyslog = host.service("rsyslog")
    assert rsyslog.is_running
    assert rsyslog.is_enabled

def test_systemdjournald_running_and_enabled(host):
    systemdjournald = host.service("systemd-journald")
    assert systemdjournald.is_running
    assert systemdjournald.is_enabled

def test_chronyd_running_and_enabled(host):
    chronyd = host.service("chronyd")
    assert chronyd.is_running
    assert chronyd.is_enabled
